const mongoose = require('mongoose');

const BloodSchema = new mongoose.Schema({
  type: { type: String, required: true },
  rh: { type: String },
  description: { type: String },
  quantity: { type: Number, default: 0 },
  location: { type: String },
  lastUpdated: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Blood', BloodSchema);
