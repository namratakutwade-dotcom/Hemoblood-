require('dotenv').config();
const mongoose = require('mongoose');
const Blood = require('./models/Blood');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/hemoblood';

mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(async () => {
    console.log('Connected, seeding data...');
    const items = [
      { type: 'A+', quantity: 10, location: 'City Hospital' },
      { type: 'A-', quantity: 4, location: 'Health Center' },
      { type: 'B+', quantity: 7, location: 'Red Cross' },
      { type: 'B-', quantity: 3, location: 'Community Blood Bank' },
      { type: 'AB+', quantity: 2, location: 'City Hospital' },
      { type: 'O+', quantity: 12, location: 'Metro Hospital' },
      { type: 'O-', quantity: 6, location: 'State Medical Center' },
      { type: 'Cord blood', description: 'Stem-cell rich cord blood', quantity: 1, location: 'Maternity Center' }
    ];
    await Blood.deleteMany({});
    await Blood.insertMany(items);
    console.log('✅ Seed data inserted successfully!');
    process.exit(0);
  })
  .catch(err => {
    console.error('Error seeding data:', err);
    process.exit(1);
  });
