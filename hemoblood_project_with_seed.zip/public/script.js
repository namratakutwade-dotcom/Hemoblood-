const apiUrl = '/api/blood';
const tbody = document.querySelector('#tbl tbody');
const form = document.getElementById('addForm');

async function fetchList(filter='') {
  const query = filter ? `?type=${encodeURIComponent(filter)}` : '';
  const res = await fetch(apiUrl + query);
  const data = await res.json();
  render(data);
}

function render(list) {
  tbody.innerHTML = '';
  list.forEach(item => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${item.type}</td>
      <td>${item.quantity}</td>
      <td>${item.location || ''}</td>
      <td class="small">${new Date(item.lastUpdated).toLocaleString()}</td>
      <td>
        <button data-id="${item._id}" class="inc">+1</button>
        <button data-id="${item._id}" class="dec">-1</button>
        <button data-id="${item._id}" class="del">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

tbody.addEventListener('click', async (e) => {
  if (e.target.matches('.inc') || e.target.matches('.dec')) {
    const id = e.target.dataset.id;
    const rowRes = await fetch(apiUrl + '/' + id);
    const item = await rowRes.json();
    const delta = e.target.matches('.inc') ? 1 : -1;
    const updated = { quantity: Math.max(0, (item.quantity || 0) + delta), lastUpdated: new Date() };
    await fetch(apiUrl + '/' + id, { method: 'PUT', headers: {'Content-Type':'application/json'}, body: JSON.stringify(updated) });
    fetchList(document.getElementById('filterType').value.trim());
  } else if (e.target.matches('.del')) {
    const id = e.target.dataset.id;
    if (!confirm('Delete this record?')) return;
    await fetch(apiUrl + '/' + id, { method: 'DELETE' });
    fetchList(document.getElementById('filterType').value.trim());
  }
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(form);
  const payload = {
    type: fd.get('type'),
    quantity: Number(fd.get('quantity') || 0),
    location: fd.get('location')
  };
  await fetch(apiUrl, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  form.reset();
  fetchList();
});

document.getElementById('btnFilter').addEventListener('click', () => {
  fetchList(document.getElementById('filterType').value.trim());
});
document.getElementById('btnClear').addEventListener('click', () => {
  document.getElementById('filterType').value = '';
  fetchList();
});

fetchList();
